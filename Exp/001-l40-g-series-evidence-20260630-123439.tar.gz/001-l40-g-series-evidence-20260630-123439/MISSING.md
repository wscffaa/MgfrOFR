# Provenance status for G1/G2/G4/R1

Generated at: 2026年 06月 30日 星期二 12:35:23 CST
Searched under: /mnt/data/Antigravity_OFR/projects/001-reidmamba

## Summary
- All four variants have train logs, test logs, and result output directories.
- Each variant has a final 200000-iteration generator checkpoint (net_g_200000.pth) and training states (*.state).
- No file named net_g_best.pth exists anywhere under the project.
- No standalone metrics.json / nr_metrics.json / test_result.json / metrics.yaml / ablation_results.yaml files exist under the project; metrics are embedded in test_*.log.

## Per-variant found counts

### Variant G1 (mgfrofr_g1)
- train YAML: projects/001-reidmamba/Exp/options/train/mgfrofr_g1.yml (present)
- train logs: 6
- test logs: 3
- result output dirs: projects/001-reidmamba/Exp/experiments/mgfrofr_g1 projects/001-reidmamba/Exp/experiments/mgfrofr_g1_archive_12token_20260620_113005 projects/001-reidmamba/Exp/experiments/mgfrofr_g1_archived_20260620_113031 projects/001-reidmamba/Exp/results_best_g1/mgfrofr_g1_davis projects/001-reidmamba/Exp/results_best_g1/mgfrofr_g1_reds projects/001-reidmamba/Exp/results_best_g1/mgfrofr_g1_srwov projects/001-reidmamba/Exp/tb_logger/mgfrofr_g1 projects/001-reidmamba/Exp/tb_logger/mgfrofr_g1_archived_20260620_113031 
- net_g_200000.pth: projects/001-reidmamba/Exp/experiments/mgfrofr_g1/models/net_g_200000.pth 
- *.state training states: 41
- net_g_best.pth: none found

### Variant G2 (mgfrofr_g2)
- train YAML: projects/001-reidmamba/Exp/options/train/mgfrofr_g2.yml (present)
- train logs: 9
- test logs: 3
- result output dirs: projects/001-reidmamba/Exp/experiments/mgfrofr_g2 projects/001-reidmamba/Exp/experiments/mgfrofr_g2_archive_12token_20260620_113005 projects/001-reidmamba/Exp/experiments/mgfrofr_g2_archived_20260620_113030 projects/001-reidmamba/Exp/results_best_g2/mgfrofr_g2_davis projects/001-reidmamba/Exp/results_best_g2/mgfrofr_g2_reds projects/001-reidmamba/Exp/results_best_g2/mgfrofr_g2_srwov projects/001-reidmamba/Exp/tb_logger/mgfrofr_g2 projects/001-reidmamba/Exp/tb_logger/mgfrofr_g2_archived_20260620_113030 
- net_g_200000.pth: projects/001-reidmamba/Exp/experiments/mgfrofr_g2/models/net_g_200000.pth 
- *.state training states: 62
- net_g_best.pth: none found

### Variant G4 (mgfrofr_g4)
- train YAML: projects/001-reidmamba/Exp/options/train/mgfrofr_g4.yml (present)
- train logs: 5
- test logs: 4
- result output dirs: projects/001-reidmamba/Exp/experiments/mgfrofr_g4 projects/001-reidmamba/Exp/results_best_g4/mgfrofr_g4_davis projects/001-reidmamba/Exp/results_best_g4/mgfrofr_g4_reds projects/001-reidmamba/Exp/results_best_g4/mgfrofr_g4_srwov projects/001-reidmamba/Exp/tb_logger/mgfrofr_g4 
- net_g_200000.pth: projects/001-reidmamba/Exp/experiments/mgfrofr_g4/models/net_g_200000.pth 
- *.state training states: 40
- net_g_best.pth: none found

### Variant R1 (mgfrofr_r1_tau005)
- train YAML: projects/001-reidmamba/Exp/options/train/mgfrofr_r1.yml (present)
- train logs: 4
- test logs: 3
- result output dirs: projects/001-reidmamba/Exp/experiments/mgfrofr_r1_tau005 projects/001-reidmamba/Exp/experiments/mgfrofr_r1_tau005_archived_20260620_172614 projects/001-reidmamba/Exp/results_best_r1_tau005/mgfrofr_r1_tau005_davis projects/001-reidmamba/Exp/results_best_r1_tau005/mgfrofr_r1_tau005_reds projects/001-reidmamba/Exp/results_best_r1_tau005/mgfrofr_r1_tau005_srwov projects/001-reidmamba/Exp/tb_logger/mgfrofr_r1_tau005 projects/001-reidmamba/Exp/tb_logger/mgfrofr_r1_tau005_archived_20260620_172614 
- net_g_200000.pth: projects/001-reidmamba/Exp/experiments/mgfrofr_r1_tau005/models/net_g_200000.pth 
- *.state training states: 40
- net_g_best.pth: none found

## Searched directories
  - projects/001-reidmamba/Exp/experiments/mgfrofr_g1_archive_12token_20260620_113005
  - projects/001-reidmamba/Exp/experiments/mgfrofr_g1
  - projects/001-reidmamba/Exp/experiments/mgfrofr_g1_archived_20260620_113031
  - projects/001-reidmamba/Exp/results_best_g1/mgfrofr_g1_davis
  - projects/001-reidmamba/Exp/results_best_g1/mgfrofr_g1_reds
  - projects/001-reidmamba/Exp/results_best_g1/mgfrofr_g1_srwov
  - projects/001-reidmamba/Exp/tb_logger/mgfrofr_g1
  - projects/001-reidmamba/Exp/tb_logger/mgfrofr_g1_archived_20260620_113031
  - projects/001-reidmamba/Exp/experiments/mgfrofr_g2_archive_12token_20260620_113005
  - projects/001-reidmamba/Exp/experiments/mgfrofr_g2
  - projects/001-reidmamba/Exp/experiments/mgfrofr_g2_archived_20260620_113030
  - projects/001-reidmamba/Exp/results_best_g2/mgfrofr_g2_davis
  - projects/001-reidmamba/Exp/results_best_g2/mgfrofr_g2_srwov
  - projects/001-reidmamba/Exp/results_best_g2/mgfrofr_g2_reds
  - projects/001-reidmamba/Exp/tb_logger/mgfrofr_g2
  - projects/001-reidmamba/Exp/tb_logger/mgfrofr_g2_archived_20260620_113030
  - projects/001-reidmamba/Exp/results_best_g4/mgfrofr_g4_srwov
  - projects/001-reidmamba/Exp/results_best_g4/mgfrofr_g4_davis
  - projects/001-reidmamba/Exp/results_best_g4/mgfrofr_g4_reds
  - projects/001-reidmamba/Exp/experiments/mgfrofr_g4
  - projects/001-reidmamba/Exp/tb_logger/mgfrofr_g4
  - projects/001-reidmamba/Exp/results_best_r1_tau005/mgfrofr_r1_tau005_srwov
  - projects/001-reidmamba/Exp/results_best_r1_tau005/mgfrofr_r1_tau005_reds
  - projects/001-reidmamba/Exp/results_best_r1_tau005/mgfrofr_r1_tau005_davis
  - projects/001-reidmamba/Exp/experiments/mgfrofr_r1_tau005
  - projects/001-reidmamba/Exp/experiments/mgfrofr_r1_tau005_archived_20260620_172614
  - projects/001-reidmamba/Exp/tb_logger/mgfrofr_r1_tau005
  - projects/001-reidmamba/Exp/tb_logger/mgfrofr_r1_tau005_archived_20260620_172614

## Globally absent files
- metrics.yaml: 0 found
- ablation_results.yaml: 0 found
- nr_metrics.json: 0 found
- test_result.json: 0 found
- net_g_best.pth: 0 found
